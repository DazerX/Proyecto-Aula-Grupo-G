package Entidades;

import java.time.LocalDate;
import java.util.ArrayList;

public class Nomina {

    private Tecnico tecnico;
    private double pago;
    private ArrayList<Factura> listaFacturas;
    private LocalDate fechaInicio;
    private LocalDate fechaFinal;
    private ArrayList<Servicio> serviciosTecnico;
    private ArrayList<LocalDate> fechaRealizaciones;

    public Nomina(Tecnico tecnico, ArrayList<Factura> listaFacturas, LocalDate fechaInicio, LocalDate fechaFinal) {
        this.tecnico = tecnico;
        this.pago = 0;
        this.listaFacturas = listaFacturas;
        this.fechaInicio = fechaInicio;
        this.fechaFinal = fechaFinal;
        this.serviciosTecnico = new ArrayList();
        this.fechaRealizaciones = new ArrayList();
    }

    public Tecnico getTecnico() {
        return tecnico;
    }

    public void setTecnico(Tecnico tecnico) {
        this.tecnico = tecnico;
    }

    public double getPago() {
        return pago;
    }

    public void setPago(double pago) {
        this.pago = pago;
    }

    public ArrayList<Factura> getListaFacturas() {
        return listaFacturas;
    }

    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(LocalDate fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public LocalDate getFechaFinal() {
        return fechaFinal;
    }

    public void setFechaFinal(LocalDate fechaFinal) {
        this.fechaFinal = fechaFinal;
    }

    public ArrayList<Servicio> getServiciosTecnico() {
        return serviciosTecnico;
    }

    public void setServiciosTecnico(ArrayList<Servicio> serviciosTecnico) {
        this.serviciosTecnico = serviciosTecnico;
    }

    public void addServicios(Servicio s) {
        this.serviciosTecnico.add(s);
    }

    public void setListaFacturas(ArrayList<Factura> listaFacturas) {
        this.listaFacturas = listaFacturas;
    }

    public ArrayList<Factura> rangoFacturas() {
        ArrayList<Factura> facturasRango = new ArrayList();
        for (Factura factura : this.getListaFacturas()) {
            if (factura.getFecha().isAfter(this.getFechaInicio()) && factura.getFecha().isBefore(this.getFechaFinal())) {
                facturasRango.add(factura);
            }
        }
        return facturasRango;
    }

    public ArrayList<LocalDate> getFechaRealizaciones() {
        return fechaRealizaciones;
    }

    public void setFechaRealizaciones(ArrayList<LocalDate> fechaRealizaciones) {
        this.fechaRealizaciones = fechaRealizaciones;
    }

    public void addFechasRealizacion(LocalDate fecha) {
        this.fechaRealizaciones.add(fecha);
    }

    public void calcularPago() {

        double acomulado = 0;
        ArrayList<Factura> rangoFactura = this.rangoFacturas();
        if (rangoFactura == null) {
            System.out.println("No existen facturas creadas");
        } else {
            for (Factura f : this.rangoFacturas()) {
                //En caso de ser tecnico Unico y haya prestado un servicio en una factura 
                //con un servicio
                if (this.tecnico.getTipoTecnico().equals("Tecnico monoServicio")) {
                    TUnico tec = (TUnico) this.tecnico;
                    if (f.getTech() != null) {
                        if (f.getTech().getCedula().equals(tec.getCedula()) && f.getServicio().getCodigo().equals(tec.getOficio().getCodigo())) {
                            acomulado += f.getPrecio() * f.getServicio().getPorcentaje();
                        }
                    }
                    //En caso de ser tecnico Unico y haya prestado un servicio en una factura 
                    //con multiservicios
                    if(f.getServicios()!=null){
                    for (Servicio servicioFactura : f.getServicios()) {
                        for (Tecnico tecnicoFactura : f.getTecnicos()) {
                            if (tecnicoFactura.getCedula().equals(tec.getCedula()) && servicioFactura.getCodigo().equals(tec.getOficio().getCodigo())) {
                                acomulado += servicioFactura.getCosto() * servicioFactura.getPorcentaje();
                            }
                        }
                    }
                    }
                } else {

                    //codigo sin revisar
                    TMultiservicio tecnico = (TMultiservicio) this.tecnico;
                    //En caso de ser tecnico Multiservicio y haya prestado un servicio en una factura 
                    //con un Unico servicio
                    for (Servicio servicioTecnico : tecnico.getOficios()) {
                        if (f.getTech() != null && servicioTecnico != null) {
                            if (f.getTech().getCedula().equals(tecnico.getCedula()) && f.getServicio().getCodigo().equals(servicioTecnico.getCodigo())) {
                                acomulado += f.getPrecio() * f.getServicio().getPorcentaje();
                            }
                            //En caso de ser tecnico Multiservicio y haya prestado un servicio en una factura 
                            //con multiservicios
                            for (Servicio servicio : f.getServicios()) {
                                if (f.getTech().getCedula().equals(tecnico.getCedula()) && servicio.getCodigo().equals(servicioTecnico.getCodigo())) {
                                    acomulado += f.getPrecio() * servicio.getPorcentaje();
                                }
                            }
                        }
                    }
                }
            }
            this.setPago(acomulado);
        }

    }

    public void ImprimirNomina() {

        ArrayList<Factura> rangoFactura = this.rangoFacturas();
        if (rangoFactura == null) {
            System.out.println("No existen facturas creadas");
        } else {

            System.out.println("Nomina de empleado\n ");
            this.tecnico.MostrarTecnico();
            System.out.println("valor a pagar= " + this.getPago() + "\n");
           /* System.out.println("Servicios realizados en fecha inicio " + this.fechaInicio + "   / fecha final   " + this.fechaFinal);

            for (Factura f : rangoFactura) {
                if(f.getTech() != null && f.getServicio()!=null){
                if (this.tecnico.getCedula().equals(f.getTech().getCedula())) {
                    System.out.println(f.getServicio().getNombreServicio() + f.getFecha().toString());
                }
                }
                if (f.getTecnicos() != null && f.getServicio() !=null) {
                    for (Tecnico t : f.getTecnicos()) {
                        if (this.getTecnico().getCedula().equals(t.getCedula()));
                        System.out.println(f.getServicio().getNombreServicio() + f.getFecha().toString());
                    }
                }
            }*/
        }
    }
}
