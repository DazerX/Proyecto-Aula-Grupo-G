package Vista;



public class Principal {

    public static void main(String[] args) {
        Vista menu = new Vista();

        menu.IniciarSesion();
        //Al momento de la nomina colocar un dia anterior a
        //la fecha de inicio y un dia despues a la fecha final
        
        //contraseña 1234
    }

}
